package br.com.petshopsi.classes;

public class SolicitarServico {

    private String checkBoxBanho, checkBoxTosa, checkBoxTransporte, datasolicitacao;


    public SolicitarServico() {

    }

    public String getCheckBoxBanho() {
        return checkBoxBanho;
    }

    public void setCheckBoxBanho(String checkBoxBanho) {
        this.checkBoxBanho = checkBoxBanho;
    }

    public String getCheckBoxTosa() {
        return checkBoxTosa;
    }

    public void setCheckBoxTosa(String checkBoxTosa) {
        this.checkBoxTosa = checkBoxTosa;
    }

    public String getCheckBoxTransporte() {
        return checkBoxTransporte;
    }

    public void setCheckBoxTransporte(String checkBoxTransporte) {
        this.checkBoxTransporte = checkBoxTransporte;
    }

    public String getDatasolicitacao() {
        return datasolicitacao;
    }

    public void setDatasolicitacao(String datasolicitacao) {
        this.datasolicitacao = datasolicitacao;
    }
}


